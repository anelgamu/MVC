package com.neko.mvc.App;

import com.neko.mvc.Nuevo.NuevoBusinessController;
import com.neko.mvc.Nuevo.NuevoViewController;
import com.neko.mvc.Principal.PrincipalBusinessController;
import com.neko.mvc.Principal.PrincipalViewController;
import com.neko.mvc.Segundo.SegundoBusinessController;
import com.neko.mvc.Segundo.SegundoViewController;

/**
 * Created by secapp on 11/04/2016.
 */
public class InjectionManager {

    private static InjectionManager instance;
    private static final Boolean isDev = true;


    public static InjectionManager getInstance() {
        if (instance == null) {
            instance = new InjectionManager();
        }
        return instance;
    }

    public void startPrincipal(PrincipalMasterViewController principalMasterController){
        MasterBusinessController masterBusinessController = new MasterBusinessController();

        PrincipalBusinessController principalBusinessController = new PrincipalBusinessController();
        PrincipalViewController principalViewController = new PrincipalViewController();

        principalBusinessController.setRepresentationHandler(principalViewController);

        principalViewController.setTag(PrincipalMasterViewController.PRINCIPAL_CONTROLLER);
        principalViewController.setRepresentationDelegate(principalBusinessController);
        principalViewController.setMasterViewController(principalMasterController);

        principalMasterController.addFragment(principalViewController);

        masterBusinessController.setPrincipalController(principalBusinessController);

        masterBusinessController.principalInit();
    }

    public void startNuevo(NuewvoMasterViewController nuewvoMasterViewController){
        MasterBusinessController masterBusinessController = new MasterBusinessController();


        NuevoViewController nuevoViewController = new NuevoViewController();
        NuevoBusinessController nuevoBusinessController = new NuevoBusinessController();

        nuevoBusinessController.setRepresentationHandler(nuevoViewController);
        nuevoBusinessController.setTransactionDelegate(masterBusinessController);

        nuevoViewController.setRepresentationDelegate(nuevoBusinessController);
        nuevoViewController.setTag(NuewvoMasterViewController.NUEVO_CONTROLLER);
        nuevoViewController.setMasterViewController(nuewvoMasterViewController);


        SegundoBusinessController segundoBusinessController = new SegundoBusinessController();
        SegundoViewController segundoViewController = new SegundoViewController();

        segundoBusinessController.setRepresentationHandler(segundoViewController);
        segundoBusinessController.setTransactionDelegate(masterBusinessController);

        segundoViewController.setTag(NuewvoMasterViewController.SEGUNDO_NUEVO_CONTROLLER);
        segundoViewController.setRepresentationDelegate(segundoBusinessController);
        segundoViewController.setMasterViewController(nuewvoMasterViewController);

        nuewvoMasterViewController.addFragment(nuevoViewController);
        nuewvoMasterViewController.addFragment(segundoViewController);

        masterBusinessController.setNuevoController(nuevoBusinessController);
        masterBusinessController.setSegundoController(segundoBusinessController);

        masterBusinessController.nuevoInit();
    }
}
