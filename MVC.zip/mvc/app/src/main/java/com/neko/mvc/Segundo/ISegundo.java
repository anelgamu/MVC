package com.neko.mvc.Segundo;

/**
 * Created by secapp on 18/04/2016.
 */
public interface ISegundo {

    interface ISegundoTransactionHandler{
        void startSegundo();
    }

    interface ISegundoTransactionDelegate{
    }

    //Comunica de BusinessController a ViewController
    interface ISegundoRepresentationHandler{
        void showSegundo();
    }
    //Comunica de Service a BusinessComtroller
    interface ISegundoInformationDelegate{

    }
    //Comunica de BusinessController a Service
    interface ISegundoInformationHandler{

    }
    //Comunica de ViewController a Businnes
    interface ISegundoRepresentationDelegate{
    }

}
