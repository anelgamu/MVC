package com.neko.mvc.Interfaces;

/**
 * Created by dgalindo on 3/24/16.
 */
public interface IBackPressed {
    void onBackPressed();
}
