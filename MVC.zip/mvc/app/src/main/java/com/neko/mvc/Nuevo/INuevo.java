package com.neko.mvc.Nuevo;

/**
 * Created by secapp on 18/04/2016.
 */
public interface INuevo {

    interface INuevoTransactionHandler{
        void startNuevo();
    }

    interface INuevoTransactionDelegate{
        void goToSegundo();
    }

    //Comunica de BusinessController a ViewController
    interface INuevoRepresentationHandler{
        boolean showNuevo();
    }
    //Comunica de Service a BusinessComtroller
    interface INuevoInformationDelegate{

    }
    //Comunica de BusinessController a Service
    interface INuevoInformationHandler{

    }
    //Comunica de ViewController a Businnes
    interface INuevoRepresentationDelegate{
        void goSegundo();
    }
}
