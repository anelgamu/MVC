package com.neko.mvc.Interfaces;

import com.neko.mvc.Abstract.AbstractViewController;

/**
 * Created by dgalindo on 3/21/16.
 */
public interface IMasterViewController {
    void addFragment(AbstractViewController fr);
    void presetFragment(int tag);
    boolean presetFragment2(int tag);
    void presentMenu(int tag);
    void finishThis();
}
