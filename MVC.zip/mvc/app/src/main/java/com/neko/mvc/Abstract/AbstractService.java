package com.neko.mvc.Abstract;

/**
 * Created by bedoy on 3/29/16.
 */
public abstract class AbstractService
{
    /*protected Context mContext;
    protected IMementoHandler mMementoHandler;
    protected UserPreferences userPreferences;
    protected SpiceManager spiceManager;
    protected Activity activity;
    protected IMessageRepresentationHandler messageRepresentationHandler;


    public void setActivity(Activity activity) {
        this.activity = activity;
    }

    public void setContext(Context context) {
        mContext = context;
    }

    public void setMementoHandler(IMementoHandler mementoHandler) {
        mMementoHandler = mementoHandler;
    }

    //TODO verify if we could use memento as user preferences
    public void setUserPreferences(UserPreferences userPreferences) {
        this.userPreferences = userPreferences;
    }

    public void setSpiceManager(SpiceManager spiceManager) {
        this.spiceManager = spiceManager;
    }

    public void setMessageRepresentationHandler(IMessageRepresentationHandler messageRepresentationHandler) {
        this.messageRepresentationHandler = messageRepresentationHandler;
    }*/
}
