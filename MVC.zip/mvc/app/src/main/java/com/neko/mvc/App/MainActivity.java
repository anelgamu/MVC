package com.neko.mvc.App;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.neko.mvc.R;

public class MainActivity extends AppCompatActivity {
    private Button com,nue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        com = (Button)findViewById(R.id.goPrincipal);
        nue = (Button)findViewById(R.id.nuevoMVC);
        com.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplication(),PrincipalMasterViewController.class));
            }
        });

        nue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,NuewvoMasterViewController.class));
            }
        });
    }
}
