package com.neko.mvc.Abstract;

import android.app.Activity;

import com.neko.mvc.Interfaces.IMementoHandler;

/**
 * Created by dgalindo on 3/17/16.
 */
public abstract class AbstractBusinessController {

    protected IMementoHandler mementoHandler;
    protected Activity activity;

    public void setMementoHandler(IMementoHandler mementoHandler) {
        this.mementoHandler = mementoHandler;
    }

    public void setActivity(Activity activity) {
        this.activity = activity;
    }
}
