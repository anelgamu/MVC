package com.neko.mvc.Segundo;

import android.util.Log;

import com.neko.mvc.Abstract.AbstractBusinessController;

/**
 * Created by secapp on 18/04/2016.
 */
public class SegundoBusinessController extends AbstractBusinessController
        implements ISegundo.ISegundoTransactionHandler,
        ISegundo.ISegundoRepresentationDelegate {

    private ISegundo.ISegundoRepresentationHandler representationHandler;
    private ISegundo.ISegundoTransactionDelegate transactionDelegate;

    public void setRepresentationHandler(ISegundo.ISegundoRepresentationHandler representationHandler){
        this.representationHandler=representationHandler;
    }

    public void setTransactionDelegate(ISegundo.ISegundoTransactionDelegate transactionDelegate){
        this.transactionDelegate=transactionDelegate;
    }

    @Override
    public void startSegundo() {
        Log.d("SegundoBusiness---->", "Aqui!");
        representationHandler.showSegundo();
    }

}
