package com.neko.mvc.Principal;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.neko.mvc.Abstract.AbstractViewController;
import com.neko.mvc.R;

/**
 * Created by secapp on 11/04/2016.
 */
public class PrincipalViewController extends AbstractViewController
        implements IPrincipal.IPrincipalRepresentationHandler {

    private IPrincipal.IPrincipalRepresentationDelegate representationDelegate;

    public void setRepresentationDelegate(IPrincipal.IPrincipalRepresentationDelegate representationDelegate){
        this.representationDelegate=representationDelegate;
    }

    @Override
    public View init(LayoutInflater inflater, ViewGroup container) {
        view = inflater.inflate(R.layout.principal_view,container,false);

        Toolbar toolbar = (Toolbar) view.findViewById(R.id.toolbar);
        toolbar.setTitle("Edit profile");
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        toolbar.setNavigationIcon(R.mipmap.ic_go_back);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().finish();
            }
        });

        return view;
    }

    @Override
    public void resume() {

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

    }

    @Override
    public void restoreData(Bundle savedInstanceState) {

    }

    @Override
    public boolean showPrincipal() {
        return masterViewController.presetFragment2(tag);
    }

    @Override
    public void onBackPressed() {
        getActivity().finish();
    }
}
