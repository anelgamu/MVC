package com.neko.mvc.App;

import android.os.Bundle;
import android.support.annotation.IntDef;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;

import com.neko.mvc.Abstract.AbstractViewController;
import com.neko.mvc.Interfaces.IMasterViewController;
import com.neko.mvc.R;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by secapp on 11/04/2016.
 */
public class PrincipalMasterViewController extends AppCompatActivity implements IMasterViewController {
    private HashMap<Integer, AbstractViewController> fragments;
    private ArrayList<Integer> tags;

    public static final int PRINCIPAL_CONTROLLER = 0;
    public static final int PRINCIPAL_ADD_FIELD_CONTROLLER = 1;


    @IntDef({PRINCIPAL_CONTROLLER,PRINCIPAL_ADD_FIELD_CONTROLLER})
    @Retention(RetentionPolicy.SOURCE)
    public @interface ProfileControllers{}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        fragments = new HashMap<>();
        tags = new ArrayList<>();

        FragmentManager fr = getSupportFragmentManager();
        if (getSupportFragmentManager().getFragments() != null) {
            for (Fragment fragment : getSupportFragmentManager().getFragments()) {
                if (fragment != null) {
                    fr.beginTransaction().remove(fragment).commit();
                    getSupportFragmentManager().executePendingTransactions();
                }
            }
        }

        InjectionManager.getInstance().startPrincipal(this);

    }
    @Override
    public void addFragment(AbstractViewController fr) {
        fragments.put(fr.tag, fr);
    }

    @Override
    public void presetFragment(@ProfileControllers int tag) {
        tags.add(0,tag);
        Fragment fragment = fragments.get(tag);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.principalMasterView, fragment)
                .addToBackStack(null)
                .commit();
        getSupportFragmentManager().executePendingTransactions();
    }

    @Override
    public boolean presetFragment2(@ProfileControllers int tag) {
        tags.add(0, tag);
        Fragment fragment = fragments.get(tag);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.principalMasterView, fragment)
                .addToBackStack(null)
                .commit();

        return getSupportFragmentManager().executePendingTransactions();
    }


    @Override
    public void presentMenu(int tag) {

    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        int index = tags.remove(0);
        fragments.get(index).onBackPressed();

    }

    @Override
    public void finishThis() {
        finish();
    }
}
