package com.neko.mvc.Principal;

/**
 * Created by secapp on 11/04/2016.
 */
public interface IPrincipal {


    interface IPrincipalTransactionHandler{
        void startPrincipal();
    }
    //Comunica de BusinessController a ViewController
    interface IPrincipalRepresentationHandler{
        boolean showPrincipal();
    }
    //Comunica de Service a BusinessComtroller
    interface IPrincipalInformationDelegate{

    }
    //Comunica de BusinessController a Service
    interface IPrincipalInformationHandler{

    }
    //Comunica de ViewController a Businnes
    interface IPrincipalRepresentationDelegate{

    }
}
