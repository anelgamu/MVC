package com.neko.mvc.Nuevo;

import android.util.Log;

import com.neko.mvc.Abstract.AbstractBusinessController;

/**
 * Created by secapp on 18/04/2016.
 */
public class NuevoBusinessController extends AbstractBusinessController implements INuevo.INuevoRepresentationDelegate,
        INuevo.INuevoTransactionHandler,
        INuevo.INuevoInformationDelegate {

    private INuevo.INuevoRepresentationHandler representationHandler;
    private INuevo.INuevoTransactionDelegate transactionDelegate;

    public void setRepresentationHandler(INuevo.INuevoRepresentationHandler representationHandler){
        this.representationHandler= representationHandler;
    }

    public void setTransactionDelegate(INuevo.INuevoTransactionDelegate transactionDelegate){
        this.transactionDelegate=transactionDelegate;
    }

    @Override
    public void startNuevo() {
        representationHandler.showNuevo();
    }

    @Override
    public void goSegundo() {
        Log.d("BusinnessController-->", "Aqui!");
        transactionDelegate.goToSegundo();
    }
}
