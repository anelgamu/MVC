package com.neko.mvc.App;

import android.util.Log;

import com.neko.mvc.Nuevo.INuevo;
import com.neko.mvc.Principal.IPrincipal;
import com.neko.mvc.Segundo.ISegundo;

/**
 * Created by secapp on 11/04/2016.
 */
public class MasterBusinessController
        implements INuevo.INuevoTransactionDelegate,
                    ISegundo.ISegundoTransactionDelegate{

    private IPrincipal.IPrincipalTransactionHandler principalController;
    private INuevo.INuevoTransactionHandler nuevoTransactionHandler;
    private ISegundo.ISegundoTransactionHandler segundoController;

    public void setPrincipalController(IPrincipal.IPrincipalTransactionHandler principalController){
        this.principalController = principalController;
    }

    public void setSegundoController(ISegundo.ISegundoTransactionHandler transactionHandler){
        this.segundoController = transactionHandler;
    }

    public void setNuevoController(INuevo.INuevoTransactionHandler transactionHandler){
        nuevoTransactionHandler = transactionHandler;
    }

    public void principalInit(){principalController.startPrincipal();}

    public void nuevoInit(){nuevoTransactionHandler.startNuevo();}

    @Override
    public void goToSegundo() {
        Log.d("MasterBusiness---->", "Aqui!");
        segundoController.startSegundo();
    }
}
