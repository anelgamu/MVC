package com.neko.mvc.Principal;

import android.util.Log;

import com.neko.mvc.Abstract.AbstractBusinessController;

/**
 * Created by secapp on 11/04/2016.
 */
public class PrincipalBusinessController extends AbstractBusinessController
        implements IPrincipal.IPrincipalTransactionHandler,
        IPrincipal.IPrincipalRepresentationDelegate,
        IPrincipal.IPrincipalInformationDelegate{

    private IPrincipal.IPrincipalRepresentationHandler representationHandler;
    private IPrincipal.IPrincipalInformationHandler informationHandler;

    public void setRepresentationHandler(IPrincipal.IPrincipalRepresentationHandler representationHandler) {
        this.representationHandler = representationHandler;
    }

    public void setInformationHandler(IPrincipal.IPrincipalInformationHandler informationHandler){
        this.informationHandler=informationHandler;
    }

    @Override
    public void startPrincipal() {
        if(representationHandler.showPrincipal()){
            Log.d("Aqui----------->","Entro!");
        }else{
            Log.d("Aqui----------->","No entro!");
        }
    }
}
