package com.neko.mvc.backend;

import com.neko.mvc.Abstract.AbstractService;
import com.neko.mvc.Principal.IPrincipal;

/**
 * Created by secapp on 14/04/2016.
 */
public class PrincipalService extends AbstractService implements IPrincipal.IPrincipalInformationHandler {
}
